const apiKey = "12959d301e62971ebdec14966a2c52af";
const geoNamesUser = "JP@oficial";

let map = L.map('map', {
  worldCopyJump: true,
  maxBoundsViscosity: 1.0
}).setView([20, 0], 2);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19
}).addTo(map);

fetch('https://secure.geonames.org/citiesJSON?north=90&south=-90&east=180&west=-180&maxRows=1000&username=' + geoNamesUser)
  .then(response => response.json())
  .then(data => {
    data.geonames.forEach(city => {
      const lat = city.lat;
      const lng = city.lng;

      fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=${apiKey}`)
        .then(response => response.json())
        .then(weather => {
          const temp = weather.main.temp - 273.15;
          const humidity = weather.main.humidity;
          const wind = weather.wind.speed;

          let risk = "Low";
          let color = "yellow";

          if (temp > 35 && humidity < 30 && wind > 6) {
            risk = "Very High";
            color = "darkred";
          } else if (temp > 30 && humidity < 40) {
            risk = "High";
            color = "red";
          } else if (temp > 25) {
            risk = "Moderate";
            color = "orange";
          }

          const marker = L.circleMarker([lat, lng], {
            radius: 6,
            color: color,
            fillOpacity: 0.8
          }).addTo(map);

          marker.bindPopup(
            `<strong>${city.name}, ${city.countrycode}</strong><br>
             Temp: ${temp.toFixed(1)}°C<br>
             Humidity: ${humidity}%<br>
             Wind: ${wind} m/s<br>
             <b>Risk: ${risk}</b>`
          );
        });
    });
  });

const searchInput = document.getElementById("search");
searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();
  map.eachLayer(layer => {
    if (layer.getPopup) {
      const content = layer.getPopup().getContent().toLowerCase();
      layer.setStyle({
        opacity: content.includes(query) ? 1 : 0.2,
        fillOpacity: content.includes(query) ? 0.8 : 0.1
      });
    }
  });
});